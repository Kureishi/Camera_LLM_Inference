"""
CameraThread — captures frames from OpenCV VideoCapture in a background QThread
and emits frame_ready(np.ndarray) signals to the GUI at ~30 fps.
"""
from __future__ import annotations

import cv2
import numpy as np
from PySide6.QtCore import QThread, Signal


class CameraThread(QThread):
    """Background thread that continuously reads from a camera device."""

    frame_ready = Signal(np.ndarray)
    error       = Signal(str)

    def __init__(self, camera_source: int | str = 0, parent=None):
        super().__init__(parent)
        self.camera_source = camera_source
        self._running = False
        self._cap: cv2.VideoCapture | None = None

    # ── Public API ──────────────────────────────────────────────────────────

    def start_capture(self, camera_source: int | str | None = None) -> None:
        if camera_source is not None:
            self.camera_source = camera_source
        self._running = True
        self.start()

    def stop_capture(self) -> None:
        self._running = False
        self.wait(2000)  # give thread up to 2 s to finish

    # ── QThread lifecycle ────────────────────────────────────────────────────

    def run(self) -> None:
        if isinstance(self.camera_source, int):
            self._cap = cv2.VideoCapture(self.camera_source, cv2.CAP_DSHOW)
            if not self._cap.isOpened():
                # Try without backend hint (Linux / macOS)
                self._cap = cv2.VideoCapture(self.camera_source)
        else:
            # IP camera URL
            url = str(self.camera_source).strip()
            # If the user enters a bare IP Webcam URL like "http://10.0.0.249:8080", 
            # OpenCV needs the actual video stream endpoint, which is usually "/video".
            if url.startswith("http") and url.count("/") == 2:
                url += "/video"
            elif url.startswith("http") and url.count("/") == 3 and url.endswith("/"):
                url += "video"
            self._cap = cv2.VideoCapture(url)

        if not self._cap.isOpened():
            self.error.emit(f"Cannot open camera source: {self.camera_source}")
            return

        # Prefer 720p for a good quality / performance balance
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        self._cap.set(cv2.CAP_PROP_FPS, 30)

        while self._running:
            ret, frame = self._cap.read()
            if not ret:
                self.error.emit("Failed to read frame from camera")
                break
            # Convert BGR → RGB for Qt display
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.frame_ready.emit(frame_rgb)
            # ~30 fps → sleep ~33 ms
            self.msleep(33)

        if self._cap:
            self._cap.release()
            self._cap = None

    def __del__(self):
        self._running = False
        if self._cap:
            self._cap.release()
